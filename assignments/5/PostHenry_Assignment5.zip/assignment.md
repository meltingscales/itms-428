Create a presentation showing the creation of your virtual network with DVWA.

Explain the importance of this environment for testing database, web applications, and etc.

Assignment replaces 'Secure a database environment with applied controls.'